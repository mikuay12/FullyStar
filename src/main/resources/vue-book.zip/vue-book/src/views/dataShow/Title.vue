<script setup></script>

<template>
  <div class="header-box">
    <dv-decoration8 style="width: 300px; height: 50px" />
    <div>
      <h2>推送平台</h2>
      <dv-decoration5 :dur="2" style="width: 300px; height: 40px" />
    </div>
    <dv-decoration8 :reverse="true" style="width: 300px; height: 50px" />
  </div>
</template>

<style scoped></style>
