<script setup>
import TitleVue from "./Title.vue";
import FirstVue from "./First.vue";
import SecondVue from "./Second.vue";
import ThirdVue from "./Third.vue";
import FourthVue from "./Fourth.vue";
</script>

<template>
  <TitleVue />
  <div class="main">
    <FirstVue />
    <SecondVue />
    <ThirdVue />
    <FourthVue />
  </div>
</template>

<style scoped></style>
