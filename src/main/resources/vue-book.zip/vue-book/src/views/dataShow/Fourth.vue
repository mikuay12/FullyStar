<script setup></script>

<template><div style="border: 1px solid red">这是第4个模块</div></template>

<style scoped></style>
