<script setup>
import LoginVue from "@/views/Login.vue";
</script>

<template>
  <!-- <LoginVue /> -->
  <router-view></router-view>
</template>

<script scoped></script>
